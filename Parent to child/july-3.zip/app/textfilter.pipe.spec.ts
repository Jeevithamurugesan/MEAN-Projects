import { TextfilterPipe } from './textfilter.pipe';

describe('TextfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TextfilterPipe();
    expect(pipe).toBeTruthy();
  });
});
